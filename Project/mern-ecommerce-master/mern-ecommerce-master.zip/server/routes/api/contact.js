const express = require('express');
const router = express.Router();

// Bring in Models & Helpers
const Contact = require('../../models/contact');
const { sendMail } = require( "../../services/nodemailer" );
const { contactEmail } = require('../../config/template');
// const mailgun = require('../../services/mailgun');

router.post('/add', (req, res) => {
  const name = req.body.name;
  const email = req.body.email;
  const message = req.body.message;

  if (!email) {
    return res.status(400).json({ error: 'You must enter an email address.' });
  }

  if (!name) {
    return res
      .status(400)
      .json({ error: 'You must enter description & name.' });
  }

  if (!message) {
    return res.status(400).json({ error: 'You must enter a message.' });
  }

  const contact = new Contact({
    name,
    email,
    message
  });

  contact.save(async (err, data) => {
    if (err) {
      return res.status(400).json({
        error: 'Your request could not be processed. Please try again.'
      });
    }

    let textMsgData = contactEmail()
    await sendMail(email, textMsgData);


    // await sendMail.sendEmail (email, 'contact');

    res.status(200).json({
      success: true,
      message: `We receved your message, we will reach you on your email address ${email}!`,
      contact: data
    });
  });
});

module.exports = router;
